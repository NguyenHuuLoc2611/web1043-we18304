console.log("Hello World");
let a = 10;
//set a value of 10
alert(a);
var x= prompt("Nhap vao gia tri n: ");//Nhap dữ liệu
document.write(x);//xuất dữ liệu ra màn hình 